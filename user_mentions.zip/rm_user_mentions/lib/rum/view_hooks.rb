module RUM
  module RUM
    class Hooks < Redmine::Hook::ViewListener
      render_on(:view_layouts_base_html_head, partial: 'hooks/rum/head')
    end
  end
end